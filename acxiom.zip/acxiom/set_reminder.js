function setReminder() {
    var reminderText = document.getElementById("reminder-text").value;
    var reminderDate = document.getElementById("reminder-date").value;

    alert("Reminder set!\nMessage: " + reminderText + "\nDate and Time: " + reminderDate);
}